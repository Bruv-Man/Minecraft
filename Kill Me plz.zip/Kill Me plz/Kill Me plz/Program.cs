﻿using System;

namespace Kill_Me_plz
{
    class Program
    {
        static void Main(string[] args)
        {
            int aa = 1;
                while (aa == 1)
                {
                    Random aaa = new Random();
                    int a = aaa.Next(1, 10);
                    int b = aaa.Next(1, 10);
                    int c = aaa.Next(1, 10);
                    int d = aaa.Next(1, 10);
                    int e = aaa.Next(1, 10);
                    int f = aaa.Next(1, 10);
                    int g = aaa.Next(1, 10);
                    int h = aaa.Next(1, 10);
                    int i = aaa.Next(1, 10);
                    int j = aaa.Next(1, 10);
                    int k = aaa.Next(1, 10);
                    int l = aaa.Next(1, 10);
                    int m = aaa.Next(1, 10);
                    int n = aaa.Next(1, 10);
                    int o = aaa.Next(1, 10);
                    int p = aaa.Next(1, 10);
                    int q = aaa.Next(1, 10);
                    int r = aaa.Next(1, 10);
                    int s = aaa.Next(1, 10);
                    int t = aaa.Next(1, 10);
                    int u = aaa.Next(1, 10);
                    int v = aaa.Next(1, 10);
                    int w = aaa.Next(1, 10);
                    int x = aaa.Next(1, 10);
                    int y = aaa.Next(1, 10);
                    int z = aaa.Next(1, 10);
                    int kill = (a + b + c + d + e + f + g + h + i + j + k + l + m + n + o + p + q + r + s + t + u + v + w + x + y + z* a * b * c * d * e * f * g* h * i*j*k*l*m*n*o*p*q*r*s*t*u*v*w*x*y*z);
                Console.WriteLine(kill);
                }
            }
        }
    }
